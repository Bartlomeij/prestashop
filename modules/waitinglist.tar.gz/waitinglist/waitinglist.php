<?php

if (!defined('_PS_VERSION_'))
    exit;

class WaitingList extends Module
{
    public function __construct()
    {
        $this->name = 'waitinglist';
        $this->tab = 'front_office_features';
        $this->version = '0.1.0';
        $this->author = 'Bartłomiej Różycki';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Powerful waiting list');
        $this->description = $this->l('For my ally is the Force, and a powerful ally it is.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

//        if (!Configuration::get('FORCE_VALUE'))
//            $this->warning = $this->l('No name provided');
    }

    public function install()
    {
        if (Shop::isFeatureActive())
            Shop::setContext(Shop::CONTEXT_ALL);

        $sql = 'CREATE TABLE `ps_preorder_list`
                (
                id int,
                id_product int,
                active boolean,
                email_address varchar(255),
                data_created datetime
                );';


        if (!parent::install() ||
            !Db::getInstance()->execute($sql)
//            ||
//            !$this->registerHook('displayLeftColumn') ||
//            !$this->registerHook('displayTop') ||
//            !Configuration::updateValue('FORCE_VALUE', 100)
        )
            return false;

        return true;
    }

    public function getContent()
    {
        $html = '';

        if(Tools::isSubmit('submitUpdate'))
        {
            Configuration::updateValue('WAITING_LIST_TEXT', Tools::getValue("ourtext"));
            $html .= $this->displayConfirmation($this->l('Text Updated'));
        }

        $html .= '
            <form action="'.$_SERVER['REQUEST_URI'].'" method="post" class="defaultForm form-horizontal">
                <div class="panel">
                    <div class=""panel-heading">'.$this->l('Settings').'</div>';

        $html .= '
                    <div class="form-group">
                        <label class="control-label col-lg-3">'.$this->l('The text of the form').'</label>
                        <div class="col-lg-6">
                            <input type="text" name="ourtext" value="'.Configuration::get('WAITING_LIST_TEXT').'" />
                        </div>
                    </div>
        ';

        $html .= '
                    <input type="submit" name="submitUpdate" value="'.$this->l('Save').'" class="btn btn-default" />
                </div>
            </form>
        ';

        return $html;
    }

//    public function hookDisplayLeftColumn($params)
//    {
//        return Configuration::get('MODULEDEMO_TEST_TEXT');
//    }
//
//    public function hookDisplayTop($params)
//    {
//        return 'Fooooooooooooooooooooooooooooooooooooooooooooooo!';
//    }

    public function uninstall()
    {

        $sql = "DROP TABLE IF EXISTS `ps_preorder_list`;";
        if (!parent::uninstall() ||
            !Configuration::deleteByName('WAITING_LIST_TEXT') ||
            !Db::getInstance()->execute($sql)

        )
            return false;

        return true;
    }


}